﻿// task 1(5) user namespace
#include <iostream>
#include <fstream>
#include  "mylib.h"
using namespace MySpace;
using namespace std;


int main()
	{
	
	/*task 1(5) User namespace*/
	fArray();			 
	counting_numbers();
	printArray();
	
	/*task 2*/
	checking_numbers(); 
	
	/*task 3*/
	bubbleSort();	
	
	/*task 4*/
	StrEmp();
		
		
	return 0;
	}