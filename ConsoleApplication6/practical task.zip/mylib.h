#pragma once
// task 1(5) user namespace

int bubbleSort();
int checking_numbers();
void StrEmp();

namespace MySpace
{
	float fArray();
	int counting_numbers();
	int printArray();
}